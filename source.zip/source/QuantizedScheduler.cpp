#include "QuantizedScheduler.h"
// This class is header-only, intentionally no implementation here.